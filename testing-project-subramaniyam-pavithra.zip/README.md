Project Description:
    This project is Armed Bandit fruit game.
    This project has been developed using java language.
    Unit testing methods have been included in this project.
    6 different fruit names and BAR has been used as choices.
    Each class has a testing unit.

Author : Pavithra Subramaniyam

Software Installed : 

Below libraries are used: 
        - hamcrest-core-1.3.jar
          https://repo1.maven.org/maven2/org/hamcrest/hamcrest-core/

        - junit-4.12.jar
          https://repo1.maven.org/maven2/junit/junit/

        - cpsuite-*.jar
          https://github.com/takari/takari-cpsuite
          http://cante.net/~jaalto/tmp/cpsuite-1.2.6.jar

